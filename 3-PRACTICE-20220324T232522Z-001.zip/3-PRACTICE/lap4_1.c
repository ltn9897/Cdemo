#include<stdio.h>
void main ()
{
	int a,b,c,sum;
	printf("\n Enter any three number: ");
	printf("nInput a: ");
	scanf ("%d", &a);
	printf("nInput b: ");
	scanf ("%d", &b);
	printf("nInput c: ");
	scanf ("%d", &c);
	sum = a+b+c;
	printf("\n sum = %d",sum);
}
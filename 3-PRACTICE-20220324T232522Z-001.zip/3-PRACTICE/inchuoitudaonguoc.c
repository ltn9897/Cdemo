#include <stdio.h>
#include <string.h>
 main(){
   char arr[100],ch;
   printf("nhap mot cau: \n");
   gets(arr);
   strrev(arr);
   printf("cau da duoc dao nguoc: \n%s\n", arr);
   return 0;
}
#include <stdio.h>
main (){
	char ch,nh ;
	do { 
	printf ("nhap ky tu: ");
	scanf ("%c",&ch);
    switch (ch){
	case 'a' :
	case 'A': printf ("Ada\n"); 
	break ;
	case 'b': 
	case 'B': printf ("Basic\n");
	break;	
	case 'c':
	case 'C': printf ("Cobol\n");
	break;
	case 'd':
	case 'D': printf ("Dbase\n");
	break;
	case 'f':
	case 'F':printf ("Fortran\n");
	break;
	case 'p':
	case 'P': printf ("Pascal\n");
	break;
	case 'v':
	case 'V': printf ("Visual C ++\n");
	break;	
    }
    printf ("DO YOU WANT TO CONTINUE ? (Y/N)");
    scanf ("%c",&nh);
    getchar();
    nh= getchar();}
    while ("nh == 'y || nh=='Y'");
}
/*so ngau nhien co 50 phan tu 
va moi phan tu co so ngau nhien tu 0-100*/
#include <stdio.h>
#include <time.h>
main (){
	time_t t;
	char alpha [50];
	int x;
	srand ((unsigned) time(&t));
	for (x=0;x<=50;x++){
		alpha[x]=rand()%100;
	}
	for (x=0;x<=50;x++){
		printf ("%d\n", rand()%50 :);
	}
	getchar();
}
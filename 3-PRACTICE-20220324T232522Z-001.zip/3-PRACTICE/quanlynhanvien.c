#include<stdio.h>
struct empdatein{
		short int day;
		short int month;
		short int year;
};
	struct Employee{
		char empID[10];
		char empname[50];
		char empdatein[10];
		float empsalary;
}; 	
void menu();
void input_employee(struct Employee company[100],int i);
int input_number_of_employee();
void show_employee(struct Employee company[100],int i);
void search_employee(struct Employee company[100],int i,char empID[10]);
 	main() {
 		struct Employee Company[100];
 		int n=0,cv;       //n la so luong nhan vien
 		char empID;
 		do{
 	menu();
	 	_flushall();
	 	do{
	 		printf ("Ban chon cong viec nao: ");
	 		scanf ("%d",&cv);
	 	}while (cv > 1 || cv < 5);
	 	switch (cv){
	 		case 1 :
	 		   n = input_number_of_employee();
	 		   _flushall();
	 		   break;
	 		 case 2 :
			    input_employee(Company, n);
			    break;
    		case 3 :
    			show_employee(Company, n);
    			break;
   			case 4 :
   				printf ("Tim kiem nhan vien theo ma nhan vien\n: ");
   				printf ("Nhap ma nhan vien can tim : ");
   				gets (empID);
   				search_employee(Company , n , empID);
   				break;
			case 5 :
			 	Exit(0);	
	 	}
	 } 	
 }
 void menu{
 	printf ("CHUONG TRINH QUAN LY NHAN VIEN \n");
 printf ("1.Nhap so luong nhan vien: \n");
 printf ("2.Nhap ma nhan vien: \n");
 printf ("3.Hien thi nhan vien: \n");
 printf ("4.Tim kiem nhan vien thong qua ma : \n");
 printf ("5.Thoat chuong trinh \n");
 }
 void input_employee(struct Employee company[100],int i){
 	int i = 0;
	 struct Employee emp;
 	do{
	 	printf ("Nhap thong tin nhan vien %d: ",i + 1);
	 	printf ("\n Nhap ma nhan vien: ");
	 	_flushall();
	 	gets (emp.empID);
	 	printf ("\nNhap ten nhan vien:");
	 	_flushall();
	 	gets(emp.empname);
	 	printf ("\nNhap luong nhan vien: ");
	 	scanf("%f",&emp.empsalary);
	 	printf("\nNhap ngay dang nhap: ");
	 	scanf ("%d %d %d",&emp.empdatein.day,&emp.empdatein.month,&emp.empdatein.year)
	 	company [i++] = emp;
	 }while (i<1);
 }
int input_number_of_employee(){
	int m;
	printf ("Nhap so luong nhan vien");
	scanf ("%d",&m);
	_flushall();
	return m;
}
void show_employee(struct Employee company[100],int i){
	int i;
	struct Employee emp;
	printf ("\nDanh sach ca nhan vien:");
	printf ("Ma nhan vien\t Ten nhan vien\t luong\t ngay vao cong ty\n");
	emp = company[i];
	printf ("%s\t %s\t %10.2f\t %d")
}
void search_employee(struct Employee company[100],int i,char empID[10]){
	int i, _flag;
	struct Employee emp;
	for(i = 0; i < n; i++){
		emp = company[i];
		if(strcmp(emp.empID	, empID	) == 0){
			printf("Thong tin nhan vien tim duoc: \n");
			printf("Ma sinh vien: %s\n", empID);
			printf("Ten sinh vien: %s \n", emp.empname);
			printf("Luong nhan vien: %s\n", emp.empsalary);
			printf("Ngay vao cong ty: %d - %d - %d \n", empdatein.day, empdatein.month, empdatein.year);
			flag = 1;
		//	break;
		}
	}
	if(flag == 0){
		printf("Khong tim thay nhan vien co ma: %s\n", empID);
	}	
}


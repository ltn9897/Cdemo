#include<stdio.h>
#include<string.h>
//void Dao_nguoc_tu(char str [1000]);
//void copyWord (char des[100][1000],char str[1000],int n);
void Nhap_mang_chuoi(char str[100][1000],int n);
void Dao_nguoc_mang_chuoi(char des[100][1000],int n);
void in_mang_chuoi(char des[100][1000],int n);
  main (){
	char arrStr[100][1000];
	int n=5;
	Nhap_mang_chuoi(arrStr,n);
	Dao_nguoc_mang_chuoi(arrStr,n);
	in_mang_chuoi(arrStr,n);
}
/*void copyWord(char des[100][1000],char str[1000],int n);{
	
}*/
void Dao_nguoc_mang_chuoi(char source[100][1000],int n){
	char des[100][1000];
	int i, j;
	for (i=0,j = n-1 ; i<n ; i++,j--){
		strcpy(des[i], source[j]);
	}
		for (i=0 ; i<n ; i++){
		strcpy(source[i], des[i]);
	}
}
void in_mang_chuoi(char des[100][1000],int n){    //n la so phan tu mang,so tu da luu
	int i;
	for (i=0;i <n;i++){
	 printf("%s",des[i]);
	}
	printf ("\n");
}
/*void Dao_nguoc_tu(char str [1000]){
	char des[1000];
	 copyWord (des,str);
	 Dao_nguoc_mang_chuoi(des);
	 in_mang_chuoi(des);

}*/
void Nhap_mang_chuoi(char arrStr[100][1000],int n){
	int i;
	printf ("nhap chuoi ky tu : \n");
	for (i=0;i<n;i++){
	printf ("nhap chuoi %d: ",i+1);
	gets (arrStr[i]);	
	}
	printf("Mang chuoi vua nhap: ");
	for(i=0; i<n;i++){
		printf ("%s",arrStr[i]);
	}
	printf("\n");
}
#include<stdio.h>
int main()
{
	float a, b;
	printf ("nhap so bat ky: ");
	scanf ("%f",&a);
	b = (a*a);
	printf ("binh phuong cua %.2f la : %.2f\n ",a,b);
	}
	end;
#include<stdio.h>
#define pi 3.1416
int main ()
{ 
 float r,s,c;
printf ("nhap ban kinh r : ");
scanf ("%f",&r);
s = r*r*pi;
c = 2*r*pi;
printf ("chu vi la : %.3f \n",c);
printf ("dien tich la : %.3f \n ",s);
}
end;
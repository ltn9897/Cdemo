#include <stdio.h>
void main () {
	float p,n,r;
	p = 1000;
	n = 2.5;
	r = 10.5;
	printf("\n Amount is : %f",p*n*r/100);
	}
	
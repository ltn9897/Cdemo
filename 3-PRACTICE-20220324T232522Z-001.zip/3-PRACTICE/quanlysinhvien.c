#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<srdlib.h>
	struct student{
	char stucode[20];
	char stuname[50];
	char stucourse[30];
	struct date birth;
}

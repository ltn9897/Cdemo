#include<string.h>
#include<stdio.h>
void check(char*a,char*b,int(*cmp)());
main (){
char s1[80],s2[80];
int (*p)();
p = strcmp;
printf ("nhap chuoi 1 :");
gets (s1);
printf ("nhap chuoi 2 :");
gets (s2);
check(s1,s2,p);	
}
void check(char*a,char*b,int(*cmp)()){
	printf("testing for equality \n");
	if(*cmp)(a,b)
	printf ("equal");
	else 
	printf ("Not equal");
}
/*tao mot mang 2 chieu gom cac so nguyen
 va in ra mang do, toi da moi chieu 10 phan tu*/
 #include <stdio.h>
 main (){
 char	alpha [10][10];
 int x,y;
 time_t t;
 srand ((unsigned) time(&t)); 
 for (x=0;x<=10;x++)
   {for (y=0;y<=10;y++){
   	alpha[x]=rand()%100;
    }printf ("array of random: \n")
   } 
   for (x=0;x<10;x++)
     { for (y=0;y<=10;y++){ 
        printf ("%d",alpha[x][y]);}
     }printf ("\n");
        getchar ();
 }
 
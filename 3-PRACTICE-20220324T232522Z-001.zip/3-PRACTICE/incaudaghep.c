#include <stdio.h>
#include <string.h>
main (){
	_flushall;
	char str1[100],str2[100],*ch1,*ch2;
	ch1=str1;
	ch2=str2;
	printf ("nhap cau 1: "); gets (ch1);
	printf ("nhap cau 2: "); gets (ch2);
	/*while (*(++ch1));
	while (*(ch1++) = *(ch2++));*/
	printf ("cau da duoc ghep :%s\n", str1);
	return 0;
	
}
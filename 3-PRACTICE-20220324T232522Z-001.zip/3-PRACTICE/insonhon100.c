#include <stdio.h>
   main (){
	int i;
	for (i=1;i<100;i++){
		printf ("i=%d, ",i);
		if (i%5 == 0){
			break;
		}
	}
	printf ("\ni = %d\n",i);
	}
#include <stdio.h>
main (){
	int x,y;
	printf ("nhap so :");	scanf ("%d",&x);
	printf ("nhap so :");	scanf ("%d",&y);
	if("(x > 2000)||(x < 3000)") { printf ("%d",x); }
	if("(y>100) && (y <500)") { printf ("\n%d",y);}
	printf ("\n");
}
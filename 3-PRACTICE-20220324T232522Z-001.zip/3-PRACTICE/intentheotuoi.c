#include<stdio.h>
#include <string.h>
main (){
	int x,n=1;
	char c;
	_flushall();
	printf ("nhap so tuoi: ");
	scanf ("%d",&x);
	printf ("nhap ten: ",c);
	scanf ("%c",&c);
	getchar();
	c = getchar();
	while (n <= x){
	printf ("%c\n",c);
	n++;}
   }

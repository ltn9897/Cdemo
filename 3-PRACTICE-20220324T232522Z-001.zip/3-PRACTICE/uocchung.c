#include <stdio.h>
main(){
int a,b;
	printf ("nhap so a: ");
			scanf ("%d",&a);
			printf ("nhap so b: ");
			scanf ("%d",&b);
while(a!=b)
{
if(a>b)
{
a=a-b;
}
else b=b-a;
}
printf ("UCLN= %d\n",a);
return 0;
}
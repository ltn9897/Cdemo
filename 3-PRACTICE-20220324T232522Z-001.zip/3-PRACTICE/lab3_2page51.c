#include <stdio.h>
int main ()
{
	int tuoi;
	float luong;
   printf ("nhap so tuoi: ");
   scanf ("%d",&tuoi);
   printf ("nhap so luong: ");
   scanf ("%f",&luong);
   printf ("so tuoi cua ban : %d\n",tuoi);
   printf ("so luong cua ban: $%f\n",luong);
   }
   end;
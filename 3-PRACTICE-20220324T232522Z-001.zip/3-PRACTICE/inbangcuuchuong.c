#include<stdio.h>
main (){
 int x,n=0;
 printf ("nhap so bat ky:");
 scanf ("%d",&x);
 while (n<10){
 n++;
 printf ("%d * %d = %d\n",x,n,x*n);}
return 0;
}

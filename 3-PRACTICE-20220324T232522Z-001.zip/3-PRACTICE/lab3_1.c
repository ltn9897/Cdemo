#include<stdio.h>
void main() {
	int principal, period;
float rate, si;
principal = 1000; 
period = 3;
rate =8.5; // rate for a year
si = principal * period * rate / 100;
printf("%8.2f\n" ,si);
}
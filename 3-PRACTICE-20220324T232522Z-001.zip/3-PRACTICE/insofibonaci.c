#include<stdio.h>
main (){
  int x, y=0 ,z=1, w, t;
    printf("nhap so bat ky: ");
    scanf("%d",&x);
    for (t = 0; t < x; t++)
  {if (t <= 1)  w = t;
    else  { w = y + z;
      y = z;
      z = w;}
    printf("%d\n",w);}
}
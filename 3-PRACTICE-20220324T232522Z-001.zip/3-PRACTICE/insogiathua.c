#include <stdio.h>
int main(){
 int x,y,n=1;
 printf("nhap so de tinh giai thua: \n");
 scanf("%d", &y);
 for (x = 1; x <= y; x++)
   n = n*x;
 printf(" %d! = %d\n ",y, n);
 return 0;
}
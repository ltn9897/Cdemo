/*while (str != NUlL)   //str la dia chi cua ky tu dau tien
while (*str != '\0')*/  
//vi du ham dem ky tu
int count =0;
char *str;
while (str != '\0')
{	count ++;
	str++;
}
return count;











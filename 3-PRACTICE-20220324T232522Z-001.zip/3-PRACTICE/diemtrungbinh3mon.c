#include <stdio.h>
main (){
	int m1,m2,m3,aver ;
	char grade[4];
label_1: 
	printf ("nhap diem M1 :"); scanf ("%d",&m1);
	printf ("nhap diem M2 :"); scanf ("%d",&m2);
	printf ("nhap diem M1 :"); scanf ("%d",&m3);
	aver = (m1+m2+m3)/3;
	if (aver <=90)
		printf ("grade :E+");
		else if (aver >=80)
		printf ("grade :E");
		else if (aver >=70)
		printf ("grade :A+");
		else if (aver >=60)
		printf ("grade :A");
		else if (aver >=50)
		printf ("grade :B+");
	else (aver <50)
	printf("grade : FAIL");	
	printf("DO  YOU CONTINUE? (Y\N)");
	_flushall();
	asn = getchar ();
	while (toupper (ans) == 'Y'){
		goto label_1
	}	
	printf("diem trung binh %d and grade %s\n",aver,grade);
}
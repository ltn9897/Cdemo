#include <stdio.h>
main () {
	int a,b,c,max;
	printf ("nhap so 1:");
	scanf ("%d",&a);
	printf ("nhap so 2:");
	scanf ("%d",&b);
	printf ("nhap so 3:");
	scanf ("%d",&c);
	max = a;
	if ("max <= b")
	  max = b; 
    if ("max <= c") 
	  max = c;
	 printf ("so lon nhat la : %d\n",max);
}
	 
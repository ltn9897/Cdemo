#include <stdio.h>
main (){
	int num=2,sum = 0;
	printf ("cac so nho hon 1000\n: ");
	{for (;num <1235;num++)
	//if (num%2==0)
	 printf ("%d, ",num);
	 sum++;} 
	 printf ("\nsum= %d\n",sum);
}
#include <stdio.h>
main (){
	char kt = 'A' ,c = 'a';
	printf("dia chi cua bien kt: %x\n", &kt);
	printf("dia chi cua bien c: %x\n", &c);
	printf("ky tu %C co gia tri %d\n", kt,kt);
	printf("ky tu %C co gia tri %d\n", c,c);
  int i;
  for(i=0; i <= 25; i++){
 	if(i%20 ==0){
	 	getchar();
	 }
	}
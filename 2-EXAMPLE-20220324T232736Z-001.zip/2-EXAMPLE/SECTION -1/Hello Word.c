#include <stdio.h> //File tieu de dau
main()
{
	printf("Hello Word!\n\n");
}
	
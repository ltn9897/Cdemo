#include <stdio.h>
main () {
	int x;
	x = 0;
	printf ("enter choice (1-3) :");
	scanf ("%d", &x);
	switch (x)
	{ case 1 : 
	printf (" choice is 1\n");
	break; 
	case 2 :
	printf (" choice is 2\n");
	break ;
	case 3: 
	printf (" choice is 3\n");
	break ;
	default :
	printf ("invalid choice\n");

	}
	}
	
#include <stdio.h>
main (){
 int count ;
 count =1;
 printf ("\t This is a \n");
 for (; ;count ++)
 if (count <=6)
 {printf ("\t\t\n nice");
}
else break;
 printf (" \t\n World\n");
}
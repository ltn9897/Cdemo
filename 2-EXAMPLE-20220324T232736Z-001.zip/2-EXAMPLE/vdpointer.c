#include <stdio.h>
main (){
	int n = 0,*ptr1 = '\0',*ptr2='\0';
	printf ("ptr1 %x,ptr2 = %x\n",ptr1,ptr2);
	ptr1=&n;
 	n = 15;
	printf ("n=%d\n",n);
	printf("&n : %x\n",&n);
	printf("ptr1 = %x\n",ptr1);
	printf("&ptr1 : %x\n",&ptr1);
	printf("*ptr1 : %d\n",*ptr1);
ptr2=ptr1;
printf ("ptr2 = %x\n",ptr2);
   	printf ("*ptr2 = %d\n",*ptr2);
}
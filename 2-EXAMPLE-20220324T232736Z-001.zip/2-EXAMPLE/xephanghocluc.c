#include <stdio.h>
main () {
	int diem,x ;
	_flushall();
	printf (" nhap so diem: ",&x);
	scanf ("%d",&x);
	 if ("%d > 75")
	  {printf (" dat hang A\n");}
	else if ("60<%d<75",&x)
	  ("dat hang B\n");
	else if ("45<%d<60",&x)
	  ("dat hang C\n");
	else if ("35<%d<45",&x) 
	  ("dat hang D\n");
	else if ("%d<35",&x) 
	  ("dat hang E\n");
	}
#include <string.h>
#include <stdio.h>
 main (){
	char a, str[81],*ptr;
	printf ("\n enter a sentence :");
	gets (str);
	printf (" \n Enter character to search for: ");
	a = getchar();
	ptr = strchr (str,a);
	printf ("\n Sring stars at address: %u",str);
	printf ("\nFirst occurence od character is at address : %u",ptr);
	printf ("\nPosition of first occurrence(starting from 0) is : %d ", ptr - str);
  	
}
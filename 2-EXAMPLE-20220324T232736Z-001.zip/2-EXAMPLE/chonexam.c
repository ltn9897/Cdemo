#include <stdio.h>
main (){
int choose,ans ;
  do {
  	printf ("Test - student\n");
  	printf ("1.Ex 1\n");	
  	printf ("2.Ex 2\n");
  	printf ("3.Ex 3\n");
  	printf ("4.Exit\n");	
    do{
	printf ("Your choose ? (1-4)"); scanf ("%d",&choose);
}
  	while (choose < 1 || choose > 4);
  	  switch (choose){
	  	case 1: printf ("this is Ex 1\n");
	  	   break;
        case 2: printf ("this is Ex 2\n");
		   break;
		case 3: printf ("this is Ex 3\n");
           break;
		case 4: 
		    exit(0);     
	  }
	 printf ("Do you want to continue ? (Y/N) ");
	 _flushall();
	 ans = getchar(); 
  }while (toupper(ans) =='Y');
}
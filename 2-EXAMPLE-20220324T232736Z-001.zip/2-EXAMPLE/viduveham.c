/*viet mot ct co 2 ham*/
#include<stdio.h>
#define PI 3.14
void greeting (); //prototype ( ten nguyen ham)
long int cube (int n);//prototype ( ten nguyen ham)
void menu();
long int square (int n);
void GiaiPTBN(float b, float c);
float CVDT(int r,int x,int s );
int fact(); 
main (){
		char ans;
		int n;
		float b,c;
		float r,s,x;
		int d,g,h=1;
		do{
		menu();
	do{
	printf ("Choose your exam: (1-8)\n");
	scanf ("%d",&n);
	}while (n < 1 || n > 8);
	switch (n){
		case 1 : greeting();  //calling function
		  break;
	  	case 2 : 
		  printf ("Nhap so nguyen: ");
		  scanf ("%d",n);
		  printf ("Square of %d is %ld\n",n,square(n));
  		  break;
  		case 3 :
		  printf ("Nhap so nguyen :");
		  scanf ("%d",&n);
		  printf ("Cube %d is : %d\n",n,cube(n));
		  break;
	  	case 4 :
	  	printf ("GiaiPTBN bx + c = 0 \n");
	  	printf ("nhap so b:");
	  	scanf  ("%f",&b);
	  	printf ("nhap so c: ");
	  	scanf ("%f",&c);
	  	GiaiPTBN(b,c);
		  break;
     	case 5 :
     	    printf ("nhap ban kinh r : ");
			scanf ("%f",&r);
			printf ("chu vi la : %2.f\n",x);
			printf ("dien tich la : %2.f\n",s);
			break;
		case 6 :
			printf ("nhap so can tinh giai thua : ");
			scanf ("%d",&g);
			printf ("giai thua cua %d la : %d\n", g, h);
			fact (g,h);
			break ;	
		case 7 :
		  exit(0);    
	}
	_flushall();
	printf ("DO YOU WANT TO CONTINUE? (Y/N):");
	ans = getchar ();
	}while(toupper (ans) == 'Y');
	
}
//declaration of function
void greeting (){
	printf ("hello mr :");
	printf (" how are you: ");
}
long int cube (int n){
	//int lapphuong;
	//printf ("nhap so n :"); ko can nhap vi da co n moi can in
	//scanf ("%d",&n);
	//lapphuong = n*n*n;
	//printf ("%d",lapphuong);
	return (n*n*n);//lapphuong;
}
void menu (){
	printf ("cac bai tap cua ngon ngu C: \n");
  	printf ("1.welcome\n");	
  	printf ("2.square\n");
  	printf ("3.cube\n");
  	printf ("4.GiaiPTBN\n");
  	printf ("5.CV DT hinh tron\n");
  	printf ("6.tinhgiaithua\n");
   	printf ("7.Exit\n");
}
long int square (int n){
	return (n*n);
}
void GiaiPTBN(float b, float c){
   if (b==0)
   {if (c==0)
   printf ("PT Vo so nghiem\n");
   else 
   printf ("PTVN");
}
   printf ("PT %2.f * x + %2.f = %2.f: ",b,c,-c/b);
}
float CVDT(r,x,s){
return (s = r * r * PI);
return (x = 2 * r * PI);
}
int fact(){
	int h,d,g;
 //printf("nhap so de tinh giai thua: \n");
 //scanf("%d", &g);
 for (d = 1; d <= g; d++){
  return(h = g * d);
 }
}

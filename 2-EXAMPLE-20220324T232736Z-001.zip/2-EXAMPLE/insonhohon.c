#include <stdio.h>
main (){
	int x,y;
 for(x=1;x<=10;x++) //lap theo hang
 {
    for(y=1;y<=x;y++){ //lap theo cot
   printf ("%d ",y);
  }
  printf ("\n");
}
}
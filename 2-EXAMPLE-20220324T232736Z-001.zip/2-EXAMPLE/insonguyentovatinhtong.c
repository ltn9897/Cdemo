#include<stdio.h>
main (){
	int i=2,j,n,r,count =1;
	printf ("nhap so n: ");
	scanf ("%d",&n);
	r=i%j
	for (j=2;j<=x;j++)
	  {if (r==0)
	break;
	else 
	}
    return 0;   
}

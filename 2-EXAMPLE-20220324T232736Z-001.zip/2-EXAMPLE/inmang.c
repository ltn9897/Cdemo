/*in mot mang da cho va dung con tro de in ra*/
#include <stdio.h>
main (){
	int n=6,i,arr[n],*ptr;
		printf ("Iput an array : \n");
	ptr = arr;
	for (i=0; i<n;i++){
		printf ("Arr[%d] = ",i);
		scanf ("%d",ptr++);
	}
		printf ("Array : \n");
	ptr = arr;  //ptr = arr [0];
		printf ("Output Using index : \n");
	for (i=0; i<n;i++){
		printf ("%d ", arr[i]);
	}
		printf ("\nOutput array Using pointer : \n");
	ptr = arr;
	for (i=0; i<n;i++){
		printf ("%d ", *ptr++);
 }
	printf ("\n");
}
#include<stdio.h>
main ()
{int i,j,max;
printf (" nhap gia tri lon nhat\n");
printf ("cho gia tri co the nhap:");
scanf ("%d",&max);
for ( i = 0 ,j=max ; i <= max; i ++,j--)
printf ("\n%d + %d=%d\n",i,j,i+j);
}
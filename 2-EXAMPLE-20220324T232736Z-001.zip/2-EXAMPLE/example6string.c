#include<stdio.h>
#include<string.h>
main (){
	char hotelname1[15] = "sea view";
	char hotelname2[15] = "sea breeze";
	printf ("the old name is %s\n",hotelname1);
	printf ("the new name is %s\n",hotelname1);
	getchar ();
}
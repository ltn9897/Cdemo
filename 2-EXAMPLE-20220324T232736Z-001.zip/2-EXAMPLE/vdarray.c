#include <stdio.h>
 main (){
	int ary [10];
	int i, total , high , pos=0;
	for (i=0;i<10;i++)
	{
		printf ("\n Enter value %d:",i+1);
		scanf ("%d",&ary[i]);}	
	high = ary[0];
	for (i=1;i<10;i++)
	{
		if (ary[i]> high){
			high = ary[i];
			pos = i;
	total = total + ary [i];		
		}
		printf ("\n Highest value entered was %d at position %d",high,pos);
		printf ("\n The average of elements of ary is %d",total/i);
	}
}
